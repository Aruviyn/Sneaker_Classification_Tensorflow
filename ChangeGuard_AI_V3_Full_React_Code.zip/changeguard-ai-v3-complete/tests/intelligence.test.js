import test from 'node:test';
import assert from 'node:assert/strict';
import seed from '../src/data/mockData.json' with {type:'json'};
import intelligence from '../src/data/changeIntelligence.json' with {type:'json'};
import {allBankChanges,analyzeChange,mondayOf,weekOf,similarity,dependencyHierarchy} from '../src/lib/intelligence.js';

const requests=seed.sampleRequests;
const req0=requests[0];

test('detects real time/CI overlaps for scheduled changes',()=>{
 const result=analyzeChange(req0,requests,intelligence);
 assert.ok(result.findings.some(f=>f.kind==='ci_collision'&&f.reference==='CHG-2026-2101'));
 assert.ok(result.critical>0);
});
test('completed CRs are historical, never active scheduling collisions',()=>{
 const x={...req0,implementationStart:'2026-10-04T23:00',implementationEnd:'2026-10-05T01:00'};
 const result=analyzeChange(x,[],intelligence);
 assert.ok(!result.findings.some(f=>f.reference==='CHG-2026-1981'&&f.kind==='ci_collision'));
 assert.ok(result.history.some(h=>h.id==='CHG-2026-1981'));
});
test('finds blackout window on matched application and country',()=>{
 const x={...req0,implementationStart:'2026-10-24T20:00',implementationEnd:'2026-10-24T21:00'};
 const result=analyzeChange(x,[],intelligence);
 assert.ok(result.findings.some(f=>f.kind==='blackout'));
});
test('does not invent collisions when there is no CI/relationship overlap',()=>{
 const x={...req0,id:'LOCAL-100',applicationId:'portal',servers:['WEB-MY-01'],configurationItems:['Unrelated web asset'],implementationStart:'2026-10-21T01:00',implementationEnd:'2026-10-21T02:00',impactedCountries:['MY'],implementationGroups:['Other Team'],dependsOnCrIds:[]};
 const result=analyzeChange(x,[],intelligence);
 assert.equal(result.critical,0);
});
test('detects explicitly declared prerequisites',()=>{
 const x={...req0,dependsOnCrIds:['CHG-2026-2102']};
 const result=analyzeChange(x,requests,intelligence);
 assert.ok(result.findings.some(f=>f.kind==='upstream_dependency'));
});
test('invalid or blank schedules do not crash',()=>{
 const x={...req0,implementationStart:'',implementationEnd:'invalid'};
 const result=analyzeChange(x,requests,intelligence);
 assert.equal(result.hasWindow,false);
 assert.ok(Array.isArray(result.findings));
});
test('Monday boundary and week filtering work',()=>{
 assert.equal(mondayOf('2026-10-23'),'2026-10-19');
 const wk=weekOf(allBankChanges(requests,intelligence),'2026-10-19');
 assert.ok(wk.some(x=>x.id==='CHG-2026-2103'));
 assert.ok(!wk.some(x=>x.id==='CHG-2026-1981'));
});
test('ADO traceability follows configured release and story relations',()=>{
 const trace=dependencyHierarchy(req0,intelligence,seed);
 assert.equal(trace.release.id,'RWI-123456');
 assert.ok(trace.stories.some(x=>x.epic==='Digital Payments Modernization'));
});
test('text overlap score is a bounded heuristic',()=>{
 const score=similarity('payment security certificate renewal','payment certificate rotation');
 assert.ok(score>0&&score<=100);
});
test('changing conflict rule flags in JSON changes findings immediately',()=>{
 const adjusted=structuredClone(intelligence);
 adjusted.conflictRules.ci_collision.enabled=false;
 const result=analyzeChange(req0,requests,adjusted);
 assert.ok(!result.findings.some(f=>f.kind==='ci_collision'));
});
test('a closed explicit prerequisite is presented as outcome verification, not a scheduling collision',()=>{
 const x={...req0,dependsOnCrIds:['CHG-2026-1981'],implementationStart:'2026-10-25T22:00',implementationEnd:'2026-10-26T00:00'};
 const result=analyzeChange(x,requests,intelligence);
 assert.ok(result.findings.some(f=>f.kind==='historical_dependency'&&f.severity==='info'));
 assert.ok(!result.findings.some(f=>f.reference==='CHG-2026-1981'&&f.kind==='ci_collision'));
});
