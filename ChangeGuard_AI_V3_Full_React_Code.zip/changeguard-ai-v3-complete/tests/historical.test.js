import test from 'node:test';
import assert from 'node:assert/strict';
import seed from '../src/data/mockData.json' with {type:'json'};
import intel from '../src/data/changeIntelligence.json' with {type:'json'};
import {generatePlans} from '../src/lib/engine.js';
import {migrateIntelligence} from '../src/lib/storage.js';
import {compareHistoricalCRs,completedChanges,proposePlanLessons,applyPlanSuggestion,outcomeState,portfolioInsights} from '../src/lib/historical.js';
const base=seed.sampleRequests[0];
const req={...base,plans:generatePlans(base,seed)};

test('closed requests are retrievable and unrelated pending requests excluded',()=>{
 const results=completedChanges(seed.sampleRequests,intel);
 assert.ok(results.some(r=>r.id==='CHG-2026-1930'));
 assert.ok(!results.some(r=>r.id==='CHG-2026-2101'));
});
test('matching completed change returns traceable reasons and ranked score',()=>{
 const matches=compareHistoricalCRs(req,seed.sampleRequests,intel);
 assert.ok(matches.length>0);
 assert.ok(matches.some(x=>x.id==='CHG-2026-1930'));
 assert.ok(matches.every(x=>x.matchingReasons.length&&x.similarityScore>=0&&x.similarityScore<=100));
});
test('blank CR does not hallucinate historical precedents',()=>{
 const matches=compareHistoricalCRs({id:'NEW',shortDescription:'',applicationId:'',servers:[],configurationItems:[]},[],intel);
 assert.equal(matches.length,0);
});
test('similarity policy thresholds are applied from editable JSON',()=>{
 const adjusted={...intel,historicalPolicies:{...intel.historicalPolicies,minimumMatchScore:100}};
 const matches=compareHistoricalCRs(req,seed.sampleRequests,adjusted);
 assert.ok(matches.every(x=>x.similarityScore===100));
 assert.ok(matches.length<=compareHistoricalCRs(req,seed.sampleRequests,intel).length);
});
test('unknown or unverified outcome is not counted as successful or failed',()=>{
 assert.equal(outcomeState({outcome:'rolled_back',outcomeVerified:false}),'unknown');
 assert.equal(outcomeState({outcome:'successful',outcomeVerified:true}),'successful');
 assert.equal(outcomeState({outcome:'unknown',outcomeVerified:true}),'unknown');
});
test('lesson suggestions have source references and do not change plan until accepted',()=>{
 const original=JSON.stringify(req.plans);
 const suggestions=proposePlanLessons(req,seed.sampleRequests,intel);
 assert.ok(suggestions.length>0);
 assert.ok(suggestions.every(s=>s.sourceCrId&&s.id&&s.section));
 assert.equal(JSON.stringify(req.plans),original);
 const accepted=applyPlanSuggestion(req,suggestions[0]);
 assert.ok(accepted);
 assert.equal(accepted[suggestions[0].section].at(-1).sourceCrId,suggestions[0].sourceCrId);
 assert.equal(JSON.stringify(req.plans),original);
});
test('duplicate suggestion is rejected rather than appended twice',()=>{
 const one=proposePlanLessons(req,seed.sampleRequests,intel)[0];
 const a=applyPlanSuggestion(req,one);
 const b=applyPlanSuggestion({...req,plans:a},one);
 assert.equal(b,null);
});
test('cannot accept lesson before plan generation or with empty text',()=>{
 const one=proposePlanLessons(req,seed.sampleRequests,intel)[0];
 assert.equal(applyPlanSuggestion({...req,plans:null},one),null);
 assert.equal(applyPlanSuggestion(req,one,{description:'   '}),null);
});
test('portfolio outcomes exclude unknown closure data from rate denominator',()=>{
 const x=portfolioInsights(seed.sampleRequests,intel,seed);
 assert.equal(x.outcomes.unknown>=1,true);
 assert.equal(x.verifiedOutcomes,x.outcomes.successful+x.outcomes.unsuccessful+x.outcomes.rolled_back);
 const calc=Math.round((x.outcomes.unsuccessful+x.outcomes.rolled_back)/x.verifiedOutcomes*100);
 assert.equal(x.outcomeRate,calc);
});
test('portfolio filters by app/country and excludes historical from active list',()=>{
 const x=portfolioInsights(seed.sampleRequests,intel,seed,{applicationId:'payment',country:'SG'});
 assert.ok(x.records.every(r=>r.applicationId==='payment'&&r.impactedCountries.includes('SG')));
 assert.ok(x.activeRecords.every(r=>r.snowState!=='Closed'));
});
test('portfolio concentration respects configurable density threshold',()=>{
 const high=portfolioInsights(seed.sampleRequests,{...intel,portfolioPolicies:{riskDensityWarningThreshold:999}},seed);
 assert.equal(high.concentrationAlerts.length,0);
 const low=portfolioInsights(seed.sampleRequests,{...intel,portfolioPolicies:{riskDensityWarningThreshold:1}},seed);
 assert.ok(low.concentrationAlerts.length>0);
});
test('V2 local intelligence migrates while preserving previous edits',()=>{
 const old={bankChanges:intel.bankChanges.slice(0,13).map(x=>{const a={...x};delete a.outcome;delete a.lessonsLearned;return a;}),conflictRules:{ci_collision:{enabled:false,severity:'info'}}};
 const result=migrateIntelligence(old);
 assert.equal(result.bankChanges.length,intel.bankChanges.length);
 assert.equal(result.conflictRules.ci_collision.enabled,false);
 assert.equal(result.bankChanges.find(x=>x.id==='CHG-2026-1981').outcome,'successful');
 assert.equal(result.historicalPolicies.minimumMatchScore,intel.historicalPolicies.minimumMatchScore);
});
