import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createBlankRequest, deepCopy, evaluateEvidence, generatePlans, getReviewEligibility, validateRequest } from '../src/lib/engine.js';

const sample = JSON.parse(readFileSync(new URL('../src/data/mockData.json', import.meta.url),'utf8'));
function config() { return deepCopy(sample); }
function fixture(index=0) { const c=config(); const r=deepCopy(c.sampleRequests[index]);r.plans=generatePlans(r,c);return [r,c]; }

test('clean CR has no blocking issues despite pending UAT/regression sign-offs',()=>{
  const [req,c]=fixture(0);const r=getReviewEligibility(req,c);
  assert.equal(r.blocking.length,0,JSON.stringify(r.issues,null,2));
  assert.equal(r.canSubmitForReview,true);
  assert.equal(r.evidence.complete,false);
  assert.equal(r.canFinalApprove,false);
});
test('fully verified clean CR passes without false warnings',()=>{
  const [req,c]=fixture(2);const r=validateRequest(req,c);
  assert.equal(r.blocking.length,0,JSON.stringify(r.issues,null,2));
  assert.equal(r.warnings.length,0,JSON.stringify(r.issues,null,2));
  assert.equal(r.evidence.complete,true);
});
test('flawed CR finds date, server, release/story and scope errors',()=>{
  const [req,c]=fixture(1);const r=validateRequest(req,c);
  for(const rule of ['CR018','CR020','CR023','CR028'])assert.ok(r.issues.some(x=>x.id===rule),`Missing ${rule}`);
  assert.equal(r.planReady,false);
});
test('blank CR reports missing fields gracefully',()=>{
  const c=config();const req=createBlankRequest(c,'CR-2026-999');const r=validateRequest(req,c);
  assert.ok(r.blocking.length>5);
  assert.equal(r.evidence.complete,false);
});
test('custom template edit changes generation without engine modification',()=>{
  const [req,c]=fixture(0);c.templates.java_deployment.pit.push({title:'Custom review',description:'Verify {application} on {servers}.',owner:'Release Management',minutes:8});
  const plans=generatePlans(req,c);
  assert.ok(plans.pit.some(x=>x.title==='Custom review'));
  assert.ok(plans.pit.at(-1).description.includes('PAY-SG-01'));
});
test('cross-document country mismatch is blocking',()=>{
  const [req,c]=fixture(0);req.supportingCountries=['MY'];const r=validateRequest(req,c);
  assert.ok(r.issues.some(x=>x.id==='CR021'&&x.severity==='blocking'));
});
test('wrong server referenced in plan is caught',()=>{
  const [req,c]=fixture(0);req.plans.pit[0].description+=' Check NOTIF-MY-01.';
  const r=validateRequest(req,c);
  assert.ok(r.issues.some(x=>x.id==='CR025'));
});
test('unclear PIT wording yields a warning, not a fake hard error',()=>{
  const [req,c]=fixture(0);req.plans.pit[0].description='Make sure everything works.';
  const r=validateRequest(req,c);
  assert.ok(r.issues.some(x=>x.id==='CR027'&&x.severity==='warning'));
});
test('missing plans are a blocking validation finding',()=>{
  const [req,c]=fixture(0);req.plans=null;
  const r=validateRequest(req,c);assert.ok(r.issues.some(x=>x.id==='CR024'));
});
test('evidence must contain verified status AND a referenced file',()=>{
  const [req,c]=fixture(0);req.evidence.uat.status='verified';req.evidence.regression.status='verified';
  assert.equal(evaluateEvidence(req,c).complete,false);
  req.evidence.uat.fileName='uat.pdf';req.evidence.regression.fileName='regression.pdf';
  assert.equal(evaluateEvidence(req,c).complete,true);
});
test('lead review can be configured to require sign-offs',()=>{
  const [req,c]=fixture(0);c.policies.allowLeadReviewWithPendingSignoffs=false;
  assert.equal(getReviewEligibility(req,c).canSubmitForReview,false);
});
test('no sign-offs silently marked verified when input is pending',()=>{
  const [req,c]=fixture(0);generatePlans(req,c);
  assert.equal(req.evidence.uat.status,'awaiting_signoff');
  assert.equal(req.evidence.regression.status,'in_progress');
});
