@echo off
setlocal
where node >nul 2>&1
if %errorlevel% neq 0 (
  echo Node.js was not found. Install Node.js 18 or later from https://nodejs.org/
  pause
  exit /b 1
)
where npm >nul 2>&1
if %errorlevel% neq 0 (
  echo npm was not found. Install Node.js, then try again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing React and Vite dependencies...
  call npm install
  if %errorlevel% neq 0 (
    echo Dependency installation failed. Check your connection and npm configuration.
    pause
    exit /b 1
  )
)
echo Starting ChangeGuard AI V3...
call npm run dev
pause
