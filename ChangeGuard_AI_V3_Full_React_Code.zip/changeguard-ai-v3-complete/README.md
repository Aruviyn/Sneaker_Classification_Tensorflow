# ChangeGuard AI 3.0 — Frontend-Only React Hackathon Prototype

Complete interactive React + Vite prototype for **Change Plan generation, PIT/Backout planning, CR self-review, cross-change conflict analysis, completed-CR lessons, reviewable plan suggestions and portfolio-wide risk visibility**.

## Quick start

Requires **Node.js 18+**.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually **http://localhost:5173**).

To create a production build:

```bash
npm run build
npm run preview
```

To run the automated core-logic tests:

```bash
npm test
```

## What is implemented

- Navy/light dashboard based on the approved UI direction
- **25 change request fields** across a **6-step wizard**:
  1. Basic Information
  2. Classification
  3. Scope & Schedule
  4. Implementation Details (editable generated plans)
  5. Evidence & References
  6. Review & Submit
- Dynamic template-based generation of **Implementation, PIT, Backout, Risk & Impact** plans
- Reference-driven app/service, country, server, release and ADO story selection
- **28 configurable validation rules** (including cross-document consistency and ambiguous instructions)
- Evidence tracker: **UAT sign-off, Regression sign-off, UVT plan**
- Pending sign-offs do **not** automatically count as draft validation failures
- Separate **plan quality** and **evidence readiness** indicators
- Configurable **lead-review-with-pending-signoffs** policy
- Supporting reference lists: countries, servers, release item, ADO stories
- Save/edit/duplicate/delete CRs in browser storage
- Templates and rules JSON editors; reference-data JSON editor
- Reports with CSV export
- Export change package as JSON or printable, self-contained HTML
- Two strong demo scenarios (complete CR with pending sign-offs; deliberately flawed CR), plus two additional examples
- **Bank-Wide CR Board** with week/country/application filters, risk counters, activity chart and per-CR conflict badges
- **Conflict & Dependency Analyzer** comparing proposed changes against active/upcoming and completed CRs
- Deterministic checks for overlapping servers/CIs, related CIs, blackout windows, shared application scope, implementation-group concurrency and explicit CR prerequisites
- Completed-CR similarity search for precedents/lessons (not an active schedule conflict)
- **Mock Azure DevOps traceability:** Epic → Feature → Story and configurable release work item
- **SNOW / ServiceNow field mapping** reference for a future adapter
- **Editable conflict policies** under Templates & Rules; rules can be enabled and severity adjusted
- Pre-flight conflict summary integrated into Scope & Schedule and final Self-Review steps
- **NEW V3: Historical CR Intelligence** page comparing a proposed CR to completed changes using configurable matching weights, source evidence, outcome badges and a completed-change library.
- **NEW V3: Structured completed-change outcomes** including verified-vs-unknown status, synthetic incident links, rollback flag, planned/actual durations and approved-for-demo lessons (17 synthetic bank CRs, of which 7 are closed).
- **NEW V3: Historical Plan Improvement** panel embedded into Implementation Details. Developers can **edit, accept, dismiss or reconsider** suggested steps; accepted steps are inserted into the editable Implementation/PIT/Backout/Risk plan with the original source CR ID, without silently replacing existing work.
- **NEW V3: Bank-Wide Risk Insights** page showing active/high-risk/conflicted CR totals, outcome trends, change density heatmap, top services/countries, and a rules-based risk watchlist.
- **NEW V3: Editable Historical Matching and Portfolio Policies** under Templates & Rules.
- **NEW V3: Browser-state migration** that imports the new demo intelligence fixtures while preserving saved V2 CRs, template edits, and conflict-rule changes.
- Responsive styles for desktop and mobile

## Important architecture notes

- **NO backend is included or used.** Vite only hosts the frontend during local development.
- Initial synthetic data is in `src/data/mockData.json` (CRs/templates) and `src/data/changeIntelligence.json` (bank-wide schedule, historical completed CRs, blackouts, CI relations, ADO portfolio and mapping).
- Changes are stored in browser `localStorage` for demo purposes, not a secure company database.
- A document upload **only stores its filename and status**; it does not retain or transfer document bytes.
- No actual Azure DevOps, SharePoint, ServiceNow or banking system connections. The bank-wide board displays **synthetic mock data and local CRs only**, not the whole actual bank.
- No external AI service or trained model: smart warnings, historical retrieval, suggestions and summaries are local **deterministic checks and text heuristics**. Avoid representing them as LLM-powered. The architecture is ready for a future approved retrieval/LLM service.
- "Submit for Lead Review" updates **local demo state only**, not a real change-management workflow.
- "Verified" attachment status is a **manual demo status**, not signature validation.
- Generated plan steps are examples and **MUST be confirmed** against approved operational procedures before any real deployment.

## Configuration

- `src/data/mockData.json` — initial countries, servers, apps, releases, ADO stories, templates, validation rules, sample requests and policies.
- `src/lib/engine.js` — pure frontend generation, validation and evidence gating engine.
- `src/data/changeIntelligence.json` — editable synthetic SNOW change register, CI relationships, blackout periods, ADO hierarchy, source field mapping and conflict rules.
- `src/lib/intelligence.js` — deterministic conflict checks, completed-change comparisons, weekly aggregation and release-to-ADO hierarchy.
- `src/lib/historical.js` — historical matching, outcome categorization, draft plan suggestions, acceptance safety, portfolio aggregation.
- `src/components/HistoricalPages.jsx` — completed-change library and the reviewable recommendations UI used in the CR wizard.
- `src/components/PortfolioPage.jsx` — bank-wide executive insights, synthetic outcome analysis, heatmap and change watchlist.
- `src/components/IntelligencePages.jsx` — bank-wide board, analyzer, history comparison, ADO links and mapping panel.
- `src/lib/storage.js` — browser-storage persistence.
- `src/lib/export.js` — download JSON/HTML/CSV.
- `src/App.jsx` — navigation and dashboard, configuration, reports, request storage.
- `src/components/RequestWizard.jsx` — six-step end-to-end user journey.
- `src/styles.css` — visual styling.

### Editing templates or rules

In the app, go to **Templates & Rules** and edit valid JSON, including **Conflict Detection Rules**, **Historical Matching Policy**, and **Portfolio Policy** tabs. Generated templates support these tokens:

- `{application}`
- `{servers}`
- `{countries}`
- `{release}`
- `{scope}`

A custom validation rule can refer to any supported operator in `engine.js`; adding an *entirely new* operator still requires code. Rule instances, fields, severities and enabling/disabling are configurable without changing source code.

## Suggested seven-minute V3 demo

1. Open **CR-2026-001** and show the generated Implementation/PIT/Backout/Risk plans and legitimately pending UAT/Regression sign-offs.
2. On **Implementation Details**, scroll to **Historical Plan Improvement**. Review a synthetic matching completed payment CR and a lesson with its source ID. Edit a recommendation and **Accept into Plan**; confirm the step appears in the corresponding plan tab. Demonstrate **Dismiss** on another proposal.
3. On **Review & Submit**, run original CR validation (35% generation + 30% validation are still the scoring priorities); inspect any conflicts through **Conflict & Dependency AI**.
4. Open **Historical CR Intelligence**, compare the current CR with prior completed changes, inspect unknown vs verified outcomes, and optionally update a **mock** historical outcome note.
5. Open **Bank-Wide CR Board** for the week starting 2026-10-19, filter by country or application, and open a detected overlapping change.
6. Open **Bank-Wide Risk Insights** for the whole mock portfolio: outcome categories, per-service exposure, heatmap, conflicts and prioritized review watchlist.
7. Export the final review package as HTML/JSON. No operation represents a real bank submission or approval.

## Production gaps (deliberately out of scope)

Authentication/SSO, permission management, audit immutability, workflow approval integration, server-side policy enforcement, secure attachment storage, actual file parsing, corporate inventory/ADO API integrations, LLM inference, RAG grounding, CSRF/security hardening, and enterprise monitoring.

## Conflict detector semantics and limitations

- **Critical:** active non-closed overlapping CR on the same CI/server, or matching blackout window.
- **Warning:** related-CI overlaps, same-app/country concurrency without proven shared CI, explicit prerequisites. These are **review signals**, not automatically confirmed incidents.
- **Info:** related operational teams concurrently scheduled.
- **Historical:** closed changes are shown separately as relevant examples/lessons and **never** treated as a schedule collision simply because they used the same infrastructure in the past.
- Every finding includes the linked CR, evidence, rationale and suggested action. Severity is configurable in `changeIntelligence.json` and via the application.
- The numeric readiness/risk indicator is a **heuristic**, not a probability of failed deployment. The semantic/keyword matcher is not an LLM.
- No conflict detector is complete without authoritative server/CI lists, CMDB relationships, approved maintenance/blackout calendars, correct local-time handling, and current change statuses.
- Cross-change checks are **separate** from existing plan-quality validation and do not silently approve/reject formal CR submissions.

## Future enterprise integration design (NOT implemented)

**SNOW/ServiceNow:** Create an approved read-only server-side adapter that periodically imports change records, affected CIs, parent/child and service-CI CMDB relationships, tasks, approvals, native conflict findings, blackout and maintenance calendars, and historical outcomes. Normalize `sys_id`/change number to canonical IDs; preserve source timestamps/links. Initially compare ChangeGuard findings with SNOW's authoritative native conflict results.

**Azure DevOps:** Use approved server-side credentials and the WIQL/work-item REST APIs to load release work items, Epic/Feature/Story hierarchy and relation links. In some organizations, `Release Work Item` is a custom work item type: map this per ADO project, rather than assuming Microsoft has a global standard release type.

**Bank-wide view:** Implement a central authorized aggregator/index with identity/SSO and service-/country-level access checks, audit history, pagination and incremental synchronization. Never attempt to expose other teams' restricted CR details via client-side-only filtering.

**AI (optional):** Use permission-filtered retrieval of approved historical change records and approved playbooks. Employ embeddings for candidate retrieval, then a grounded LLM to draft cautious explanations and suggest missing dependencies, always linking exact source CRs and evidence. Deterministic rules remain the authoritative structural checks. Never send secrets, bank customer records or sensitive change details to an unapproved model.

## Validation

`npm test` currently runs **35 deterministic tests** spanning plan quality, sign-off readiness, completed-CR handling, overlap detection, blackout windows, explicit prerequisites, ADO traceability and empty/odd inputs.

**Build status:** Syntax parsed with the TypeScript JSX parser and all 35 core tests passed. The full Vite build was *not verified* in this environment because the npm registry/packages were unavailable; run `npm install && npm run build` locally.

## Included convenience scripts

- **Windows:** double-click `START_WINDOWS.bat` (requires Node.js and an npm connection on the first run).
- **macOS/Linux:** run `./START_MAC_LINUX.sh` from a terminal.
- **Inspect every source file:** see the separate `ChangeGuard_AI_V3_All_Source_Code.md` distributed alongside the ZIP.

### Verification when source package was prepared

- The project’s 35 Node.js logic tests passed.
- npm dependency installation could not be completed in the preparation environment due to unavailable access to npmjs.org; therefore a full Vite compilation and browser smoke test were not performed there.
