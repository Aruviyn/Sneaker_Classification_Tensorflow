import React, { useEffect, useMemo, useState } from 'react';
import {
  LayoutDashboard, FilePlus2, FolderOpen, Layers3, Database, BarChart3, Settings2, ShieldCheck,
  Menu, X, Plus, ArrowRight, Search, Download, Eye, Copy, Trash2, RotateCcw, FileText, Network, CalendarRange,
  Clock3, CheckCircle2, AlertTriangle, ClipboardList, Info, Upload, Save, ChevronRight, History
} from 'lucide-react';
import { loadState, saveState, defaults, clearState } from './lib/storage.js';
import { createBlankRequest, deepCopy, generatePlans, getReviewEligibility, nextRequestId, statusLabel } from './lib/engine.js';
import { exportJson, exportReportCsv } from './lib/export.js';
import { Field, TextInput, Select, InfoBanner, Empty } from './components/Fields.jsx';
import RequestWizard from './components/RequestWizard.jsx';
import {BankBoardPage, ConflictCenterPage} from './components/IntelligencePages.jsx';
import {HistoricalIntelligencePage} from './components/HistoricalPages.jsx';
import PortfolioPage from './components/PortfolioPage.jsx';

const NAV=[
  {id:'dashboard', label:'Dashboard',icon:LayoutDashboard},
  {id:'new',label:'New Change Request',icon:FilePlus2},
  {id:'requests',label:'My Change Requests',icon:FolderOpen},
  {id:'bank',label:'Bank-Wide CR Board',icon:CalendarRange},
  {id:'conflicts',label:'Conflict & Dependency AI',icon:Network},
  {id:'history',label:'Historical CR Intelligence',icon:History},
  {id:'portfolio',label:'Bank-Wide Risk Insights',icon:BarChart3},
  {id:'templates',label:'Templates & Rules',icon:Layers3},
  {id:'references',label:'Reference Data',icon:Database},
  {id:'reports',label:'Reports',icon:BarChart3},
  {id:'settings',label:'Settings',icon:Settings2},
];
function Status({value}) {return <span className={`status ${value}`}>{statusLabel(value)}</span>;}
function PageHeading({kicker,title,description,children}) {return <div className="page-topline"><div><div className="eyebrow">{kicker}</div><h1>{title}</h1><p className="muted">{description}</p></div><div className="top-actions">{children}</div></div>;}
function IconCard({icon:Icon,label,value,tone}) {return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={20}/></div><div><strong>{value}</strong><span>{label}</span></div></div>;}
function RequestTable({requests,config,onOpen,onDelete,onDuplicate,showSearch=true}) {
  const [search,setSearch]=useState('');const [filter,setFilter]=useState('all');
  const filtered=requests.filter(r=>(filter==='all'||r.status===filter)&&[r.id,r.shortDescription,r.requester,r.applicationId].join(' ').toLowerCase().includes(search.toLowerCase()));
  return <>
    {showSearch&&<div className="table-toolbar"><div className="search-box"><Search size={17}/><input aria-label="Search change requests" placeholder="Search by CR ID, title, requester or application" value={search} onChange={e=>setSearch(e.target.value)}/></div><select aria-label="Filter requests by status" className="input small-select" value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">All statuses</option>{['draft','in_preparation','awaiting_evidence','ready_for_review','submitted'].map(x=><option value={x} key={x}>{statusLabel(x)}</option>)}</select></div>}
    <div className="table-scroll"><table className="data-table"><thead><tr><th>CR ID</th><th>Short Description</th><th>Service / Application</th><th>Risk</th><th>Status</th><th>Plan Checks</th><th>Action</th></tr></thead><tbody>{filtered.map(r=>{const check=getReviewEligibility(r,config);return <tr key={r.id}><td><button className="text-link" onClick={()=>onOpen(r.id)}>{r.id}</button></td><td className="description-col">{r.shortDescription||<em>Untitled request</em>}</td><td>{config.applications.find(x=>x.id===r.applicationId)?.name||'—'}</td><td><span className={`risk risk-${r.riskLevel?.toLowerCase()||'medium'}`}>{r.riskLevel}</span></td><td><Status value={r.status}/></td><td><span className={check.blocking.length?'danger-text':'positive-text'}>{check.blocking.length?`${check.blocking.length} blocking`:'Passed'}</span></td><td><div className="row-actions"><button title="Open request" className="btn btn-primary btn-xs" onClick={()=>onOpen(r.id)}>Open</button>{onDuplicate&&<button title="Duplicate request" className="icon-btn" onClick={()=>onDuplicate(r.id)}><Copy size={15}/></button>}{onDelete&&<button title="Delete request" className="icon-btn danger-icon" onClick={()=>onDelete(r.id)}><Trash2 size={15}/></button>}</div></td></tr>})}</tbody></table>{!filtered.length&&<Empty title="No matching change requests">Try a different search or create a new CR.</Empty>}</div>
  </>;
}

function Dashboard({requests,config,onOpen,onNew,onRequests,onBank}) {
  const ready=requests.filter(r=>r.status==='ready_for_review').length;
  const pending=requests.filter(r=>!getReviewEligibility(r,config).evidence.complete).length;
  const draft=requests.filter(r=>r.status==='draft').length;
  const preparation=requests.filter(r=>r.status==='in_preparation').length;
  return <div className="content-page"><PageHeading kicker="CHANGE MANAGEMENT" title="Change Management Assistant" description="Create, validate and generate Change Requests, Change Plans, PIT Plans and supporting documents."><button className="btn btn-primary" onClick={onNew}><Plus size={17}/> New Change Request</button></PageHeading>
    <div className="stats-grid"><IconCard icon={FileText} label="Total Requests" value={requests.length} tone="blue"/><IconCard icon={ClipboardList} label="Draft" value={draft} tone="violet"/><IconCard icon={Clock3} label="In Preparation" value={preparation} tone="teal"/><IconCard icon={AlertTriangle} label="Awaiting Evidence" value={pending} tone="amber"/><IconCard icon={CheckCircle2} label="Ready for Review" value={ready} tone="green"/></div>
    <div className="surface-panel"><div className="panel-title"><div><h2>Recent Change Requests</h2><p>Open a request to continue plan generation, evidence tracking or self-review.</p></div><button className="link-action" onClick={onRequests}>View All <ChevronRight size={16}/></button></div><RequestTable requests={[...requests].sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt))).slice(0,6)} config={config} onOpen={onOpen} showSearch={false}/></div>
    <div className="dashboard-bottom"><div className="surface-panel quick-panel"><div className="panel-title"><h2>Quick Actions</h2></div><button className="quick-action" onClick={onNew}><FilePlus2 size={20}/><span><b>Create a New CR</b><small>Start with a guided 6-step process</small></span><ArrowRight size={17}/></button><button className="quick-action" onClick={onRequests}><ShieldCheck size={20}/><span><b>Review Existing CRs</b><small>Check validation results and sign-offs</small></span><ArrowRight size={17}/></button><button className="quick-action" onClick={onBank}><Network size={20}/><span><b>Bank-Wide CR Board</b><small>Explore weekly risk and dependencies</small></span><ArrowRight size={17}/></button></div><div className="surface-panel quick-panel"><div className="panel-title"><h2>Prototype Workflow</h2></div><ol className="workflow-list"><li>Enter the 25 CR fields and references.</li><li>Generate the four configurable plan sections.</li><li>Track pending UAT / Regression sign-offs.</li><li>Self-review and submit when rules permit.</li></ol><InfoBanner type="warning">Frontend-only demonstration with synthetic data. No backend, production API, real AI model or actual approval submission.</InfoBanner></div></div>
  </div>;
}

function RequestsPage({requests,config,onOpen,onNew,onDelete,onDuplicate}) {return <div className="content-page"><PageHeading kicker="CHANGE MANAGEMENT" title="My Change Requests" description="Search, duplicate and continue working on saved change records."><button className="btn btn-primary" onClick={onNew}><Plus size={17}/> New Change Request</button></PageHeading><div className="surface-panel"><RequestTable requests={requests} config={config} onOpen={onOpen} onDelete={onDelete} onDuplicate={onDuplicate}/></div></div>;}

function JsonEditor({label,value,onCommit,help}) {
  const [source,setSource]=useState(()=>JSON.stringify(value,null,2));
  const [message,setMessage]=useState('');
  useEffect(()=>setSource(JSON.stringify(value,null,2)),[value]);
  const commit=()=>{try{const obj=JSON.parse(source);const response=onCommit(obj);if(response)throw new Error(response);setMessage('Configuration saved successfully.');}catch(e){setMessage(`Cannot save: ${e.message}`);}};
  return <div className="json-editor"><div className="json-editor-head"><div><h3>{label}</h3><p>{help}</p></div><button className="btn btn-primary btn-sm" onClick={commit}><Save size={15}/> Save Configuration</button></div><textarea className="json-textarea" spellCheck={false} value={source} onChange={e=>{setSource(e.target.value);setMessage('');}}/><p className={`small ${message.startsWith('Cannot')?'danger-text':'positive-text'}`}>{message}</p></div>;
}
function TemplatesPage({config,onConfigChange,intelligence,onIntelligenceChange}) {
  const [tab,setTab]=useState('templates');
  const update=(key,value)=>{if(key==='templates' && (typeof value!=='object'||!value||Array.isArray(value)||Object.keys(value).length===0))return 'Templates must be a non-empty object.';if(key==='validationRules'&&(!Array.isArray(value)||value.some(x=>!x.id||!x.kind)))return 'Rules must be an array with id and kind for every entry.';onConfigChange({...config,[key]:value});return null;};
  return <div className="content-page"><PageHeading kicker="CONFIGURATION" title="Templates & Rules" description="Edit deployment patterns and validation logic as JSON without changing source code."/><div className="surface-panel"><div className="tabs top-tabs"><button className={tab==='templates'?'active':''} onClick={()=>setTab('templates')}>Plan Templates</button><button className={tab==='rules'?'active':''} onClick={()=>setTab('rules')}>Validation Rules</button><button className={tab==='conflicts'?'active':''} onClick={()=>setTab('conflicts')}>Conflict Detection Rules</button><button className={tab==='historical'?'active':''} onClick={()=>setTab('historical')}>Historical Matching Policy</button><button className={tab==='portfolio'?'active':''} onClick={()=>setTab('portfolio')}>Portfolio Policy</button></div>{tab==='historical'?<JsonEditor label="Historical Matching & Lessons Policy" value={intelligence.historicalPolicies} onCommit={v=>{if(!v||!Number.isFinite(Number(v.minimumMatchScore))||Number(v.minimumMatchScore)<0||Number(v.minimumMatchScore)>100||!v.matchingWeights)return 'Provide a minimumMatchScore between 0 and 100 and matchingWeights.';onIntelligenceChange({...intelligence,historicalPolicies:v});return null;}} help="Edit matching weights, minimum score, number of matches and suggestions. Proposed lessons still need human acceptance."/>:tab==='portfolio'?<JsonEditor label="Portfolio Risk Policy" value={intelligence.portfolioPolicies} onCommit={v=>{if(!v||!Number.isInteger(Number(v.riskDensityWarningThreshold))||Number(v.riskDensityWarningThreshold)<1)return 'Density threshold must be a positive integer.';onIntelligenceChange({...intelligence,portfolioPolicies:v});return null;}} help="Edit bank-wide change concentration threshold and risk configuration."/>:tab==='conflicts'?<JsonEditor label="Conflict Rule Configuration" value={intelligence.conflictRules} onCommit={v=>{if(!v||typeof v!=='object'||Array.isArray(v))return 'Conflict policies must be a JSON object.';if(Object.values(v).some(r=>typeof r!=='object'||!r||typeof r.enabled!=='boolean'||!['critical','warning','info'].includes(r.severity)))return 'Each conflict rule must include enabled (boolean) and severity (critical, warning, info).';onIntelligenceChange({...intelligence,conflictRules:v});return null;}} help="Change enabled flags or severities (critical, warning, info). Rules are applied immediately to all mock CR comparisons."/>:tab==='templates'?<JsonEditor label="Plan Template Library" value={config.templates} onCommit={v=>update('templates',v)} help="Configuration-driven implementation, PIT, backout and risk plans. Supported variables: {application}, {servers}, {countries}, {release}, {scope}."/>:<JsonEditor label="Validation Rule Registry" value={config.validationRules} onCommit={v=>update('validationRules',v)} help="Enable, disable or adjust rule severity. Supported operators are implemented in src/lib/engine.js."/>}</div></div>;
}
function ReferencesPage({config,onConfigChange}) {
  const [tab,setTab]=useState('applications');
  const names={applications:'Applications',servers:'Servers',countries:'Countries',releases:'Release Work Items',stories:'ADO Stories',implementationGroups:'Implementation Groups',users:'Requesters'};
  const selected=config[tab];
  return <div className="content-page"><PageHeading kicker="MOCK MASTER DATA" title="Reference Data" description="Inspect or modify local mock reference lists used by the generation and validation engines."/><div className="surface-panel"><div className="tabs top-tabs wrap-tabs">{Object.entries(names).map(([id,label])=><button className={tab===id?'active':''} key={id} onClick={()=>setTab(id)}>{label}</button>)}</div><div className="reference-description"><b>{names[tab]}</b><span>{selected?.length||0} reference records available</span></div><JsonEditor key={tab} label={`${names[tab]} JSON`} value={selected} onCommit={v=>{if(!Array.isArray(v))return 'Reference data must be a JSON array.';onConfigChange({...config,[tab]:v});return null;}} help="This edits local prototype reference data only. Existing CR values are not silently rewritten."/></div></div>;
}
function ReportsPage({requests,config}) {
  const reviewed=requests.map(r=>({...r,_result:getReviewEligibility(r,config)}));
  const total=reviewed.length||1;
  const complete=reviewed.filter(x=>x._result.evidence.complete).length;
  const planValid=reviewed.filter(x=>x._result.planReady).length;
  const pending=reviewed.filter(x=>!x._result.evidence.complete).length;
  const chart=[['Plan checks passed',planValid,'#16a886'],['Evidence complete',complete,'#3978e5'],['Evidence pending',pending,'#f0aa48']];
  return <div className="content-page"><PageHeading kicker="INSIGHTS & EXPORT" title="Reports" description="View live summaries based on local sample and edited CR data."><button className="btn btn-primary" onClick={()=>exportReportCsv(requests,config)}><Download size={16}/> Export CSV</button></PageHeading><div className="stats-grid reports-stats"><IconCard icon={FileText} label="Total CRs" value={requests.length} tone="blue"/><IconCard icon={CheckCircle2} label="Plan Quality Passed" value={planValid} tone="green"/><IconCard icon={Clock3} label="Pending Evidence" value={pending} tone="amber"/><IconCard icon={ShieldCheck} label="Sign-offs Complete" value={complete} tone="teal"/></div><div className="surface-panel"><div className="panel-title"><h2>Readiness Breakdown</h2><span className="muted small">Derived from configurable validation rules</span></div><div className="report-bars">{chart.map(([label,count,color])=><div key={label} className="report-bar-row"><span>{label}</span><div className="bar-track"><div style={{width:`${Math.round(count/total*100)}%`,background:color}}/></div><strong>{count}</strong></div>)}</div></div><div className="surface-panel"><div className="panel-title"><h2>Change Quality by Request</h2></div><div className="table-scroll"><table className="data-table"><thead><tr><th>CR</th><th>Application</th><th>Passed Rules</th><th>Blocking</th><th>Warnings</th><th>Evidence</th></tr></thead><tbody>{reviewed.map(r=><tr key={r.id}><td>{r.id}</td><td>{r.applicationId}</td><td>{r._result.passedRules}/{r._result.totalRules}</td><td className={r._result.blocking.length?'danger-text':'positive-text'}>{r._result.blocking.length}</td><td>{r._result.warnings.length}</td><td>{r._result.evidence.verifiedCount}/{r._result.evidence.total} verified</td></tr>)}</tbody></table></div></div></div>;
}
function SettingsPage({config,onConfigChange,onReset}) {
  const policy=config.policies;
  const patch=(key,value)=>onConfigChange({...config,policies:{...policy,[key]:value}});
  return <div className="content-page"><PageHeading kicker="PROTOTYPE CONFIGURATION" title="Settings" description="Control demo governance gates and reset data to the included mock fixtures."/><div className="surface-panel settings-panel"><h2>Governance Rules</h2><p className="muted">These toggles govern the prototype, not an enterprise change-management system.</p><label className="setting-line"><span><b>Allow lead review with pending UAT / Regression sign-offs</b><small>When enabled, missing sign-offs do not block initial lead review if plan checks pass.</small></span><input type="checkbox" checked={policy.allowLeadReviewWithPendingSignoffs} onChange={e=>patch('allowLeadReviewWithPendingSignoffs',e.target.checked)}/></label><label className="setting-line"><span><b>Require verified sign-offs for final evidence gate</b><small>Changes can progress in draft/review while supporting evidence is pending.</small></span><input type="checkbox" checked={policy.requireVerifiedSignoffsForFinalApproval} onChange={e=>patch('requireVerifiedSignoffsForFinalApproval',e.target.checked)}/></label><Field label="Default Deployment Template"><Select value={policy.defaultTemplate} onChange={v=>patch('defaultTemplate',v)} options={Object.entries(config.templates).map(([value,x])=>({value,label:x.label}))}/></Field></div><div className="surface-panel settings-panel"><h2>Demo Data Management</h2><p className="muted">Changes are automatically stored in this browser's localStorage. They are not backed up or shared across devices.</p><button className="btn btn-danger-outline" onClick={onReset}><RotateCcw size={16}/> Reset to Original Mock Data</button></div><InfoBanner type="warning">For a real enterprise release, add authenticated users, authorization, secure attachments, server-side validation, audit immutability, change approvals and approved systems integration.</InfoBanner></div>;
}

export default function App() {
  const [state,setState]=useState(loadState);
  const [page,setPage]=useState('dashboard');
  const [activeId,setActiveId]=useState(null);
  const [analyzeId,setAnalyzeId]=useState(null);
  const [mobileMenu,setMobileMenu]=useState(false);
  const [saveWarning,setSaveWarning]=useState(false);
  const {requests,config,intelligence}=state;
  const request=useMemo(()=>requests.find(x=>x.id===activeId),[requests,activeId]);
  useEffect(()=>{if(!saveState(state))setSaveWarning(true);},[state]);
  const go=(id)=>{if(id==='new'){create();return;}setPage(id);setMobileMenu(false);};
  const create=()=>{
    const id=nextRequestId(requests);const item=createBlankRequest(config,id);
    setState(s=>({...s,requests:[item,...s.requests]}));setActiveId(id);setPage('wizard');setMobileMenu(false);
  };
  const open=id=>{setActiveId(id);setPage('wizard');setMobileMenu(false);};
  const analyze=id=>{setAnalyzeId(id);setPage('conflicts');setMobileMenu(false);};
  const onRequestChange=patch=>setState(s=>({...s,requests:s.requests.map(r=>{
    if(r.id!==activeId)return r;
    const changed={...r,...patch,updatedAt:new Date().toISOString()};
    if(r.reviewSubmitted && Object.keys(patch).every(k=>k==='evidence')) {
      changed.status=getReviewEligibility(changed,s.config).evidence.complete?'submitted':'awaiting_evidence';
    } else {
      changed.status='in_preparation';changed.reviewSubmitted=false;
    }
    return changed;
  })}));
  const onRequestSave=()=>setState(s=>({...s,requests:s.requests.map(r=>r.id===activeId?{...r,updatedAt:new Date().toISOString()}:r)}));
  const onSubmit=()=>setState(s=>({...s,requests:s.requests.map(r=>r.id===activeId?{...r,reviewSubmitted:true,status:getReviewEligibility(r,s.config).evidence.complete?'submitted':'awaiting_evidence',updatedAt:new Date().toISOString()}:r)}));
  const duplicate=id=>{
    const orig=requests.find(r=>r.id===id);if(!orig)return;
    const newid=nextRequestId(requests);
    const copy={...deepCopy(orig),id:newid,shortDescription:`Copy of ${orig.shortDescription}`,status:'draft',reviewSubmitted:false,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
    setState(s=>({...s,requests:[copy,...s.requests]}));open(newid);
  };
  const remove=id=>{if(window.confirm(`Delete ${id} from this browser? This cannot be undone.`)){setState(s=>({...s,requests:s.requests.filter(r=>r.id!==id)}));if(activeId===id){setPage('requests');setActiveId(null);}}};
  const reset=()=>{if(window.confirm('Reset ALL changes, CRs, templates and references to original mock data?')){clearState();setState(defaults());setActiveId(null);setPage('dashboard');}};
  const setConfig=value=>setState(s=>({...s,config:value}));
  const setIntelligence=value=>setState(s=>({...s,intelligence:value}));
  return <div className="app-shell"><aside className={`sidebar ${mobileMenu?'mobile-open':''}`}><div className="brand"><div className="brand-mark"><ShieldCheck size={21}/></div><b>ChangeGuard <span>AI</span></b><button className="mobile-close icon-btn" onClick={()=>setMobileMenu(false)} aria-label="Close menu"><X size={18}/></button></div><nav className="nav-list">{NAV.map(item=>{const Icon=item.icon;const current=item.id==='new'?page==='wizard'&&request?.status==='draft':page===item.id;return <button key={item.id} className={`nav-item ${current?'active':''}`} onClick={()=>go(item.id)}><Icon size={18}/><span>{item.label}</span></button>;})}</nav><div className="sidebar-foot"><div className="profile-icon">JT</div><div><strong>John Tan</strong><small>Developer · Demo account</small></div></div><span className="sidebar-version">FRONTEND PROTOTYPE · v3.0</span></aside>{mobileMenu&&<button aria-label="Close navigation overlay" className="menu-overlay" onClick={()=>setMobileMenu(false)}/>}
    <div className="main-area"><header className="app-header"><button className="menu-toggle" onClick={()=>setMobileMenu(true)}><Menu size={21}/></button><div className="breadcrumb">ChangeGuard AI <ChevronRight size={14}/> <strong>{page==='wizard'?'Change Request':NAV.find(x=>x.id===page)?.label||'Dashboard'}</strong></div><div className="header-right"><span className="prototype-flag"><Info size={14}/> Local prototype</span><div className="header-avatar">JT</div></div></header>{saveWarning&&<div className="storage-warning">Browser storage is full or unavailable. Changes may not be saved after refresh.</div>}
    <main className="main-content">{page==='dashboard'&&<Dashboard requests={requests} config={config} onNew={create} onOpen={open} onRequests={()=>go('requests')} onBank={()=>go('bank')}/>}{page==='requests'&&<RequestsPage requests={requests} config={config} onNew={create} onOpen={open} onDuplicate={duplicate} onDelete={remove}/>}{page==='wizard'&&(request?<RequestWizard key={request.id} request={request} config={config} requests={requests} intelligence={intelligence} onAnalyze={()=>analyze(request.id)} onOpenHistory={()=>{setPage('history');setMobileMenu(false);}} onChange={onRequestChange} onSave={onRequestSave} onSubmit={onSubmit} onBack={()=>go('requests')}/>:<Empty title="Request not found">Return to My Change Requests.</Empty>)}{page==='bank'&&<BankBoardPage requests={requests} config={config} intelligence={intelligence} onOpen={open} onAnalyze={analyze} onPortfolio={()=>go('portfolio')}/>}
    {page==='history'&&<HistoricalIntelligencePage requests={requests} config={config} intelligence={intelligence} onIntelligenceChange={setIntelligence} onOpen={open}/>}
    {page==='portfolio'&&<PortfolioPage requests={requests} config={config} intelligence={intelligence} onAnalyze={analyze} onBank={()=>go('bank')}/>}
    {page==='conflicts'&&<ConflictCenterPage key={analyzeId||'default'} requests={requests} config={config} intelligence={intelligence} initialId={analyzeId} onOpen={open}/>}
    {page==='templates'&&<TemplatesPage config={config} onConfigChange={setConfig} intelligence={intelligence} onIntelligenceChange={setIntelligence}/>}{page==='references'&&<ReferencesPage config={config} onConfigChange={setConfig}/>}{page==='reports'&&<ReportsPage requests={requests} config={config}/>}{page==='settings'&&<SettingsPage config={config} onConfigChange={setConfig} onReset={reset}/>}</main></div>
  </div>;
}
