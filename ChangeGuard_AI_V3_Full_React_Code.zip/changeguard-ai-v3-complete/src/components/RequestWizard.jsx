import React, { useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, Clock3, AlertTriangle, FileCheck2, FileUp, Save, Sparkles, RefreshCw, Download, Plus, Trash2, ShieldCheck, CircleHelp, Info, Eye, ClipboardCheck } from 'lucide-react';
import { Field, TextInput, TextArea, Select, MultiSelect, InfoBanner, Empty } from './Fields.jsx';
import { SECTION_LABELS, EVIDENCE_LABELS, EVIDENCE_STATUSES, generatePlans, getReviewEligibility, statusLabel } from '../lib/engine.js';
import { exportHtml, exportJson } from '../lib/export.js';
import {ConflictPreview} from './IntelligencePages.jsx';
import {HistoricalPlanAssistant} from './HistoricalPages.jsx';

const STAGES = ['Basic Information', 'Classification', 'Scope & Schedule', 'Implementation Details', 'Evidence & References', 'Review & Submit'];
const riskOptions=['Low','Medium','High','Critical'];
const yesOptions=['Yes','No','Unknown'];
const normOptions=['Standard','Normal','Emergency'];
const sectionKeys=Object.keys(SECTION_LABELS);
const dateFmt = value => value ? new Date(value).toLocaleString('en-MY', {year:'numeric',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : 'Not entered';
function ConfigurationItemsEditor({items,onCommit}) {
  const [text,setText] = useState((items || []).join('\n'));
  return <TextArea rows={3} value={text} onChange={setText}
    onBlur={() => onCommit(text.split('\n').map(x=>x.trim()).filter(Boolean))}
    placeholder={'Payment application service\nPayment API configuration'}/>;
}
const nameForApp=(config,id)=>config.applications.find(x=>x.id===id)?.name || '—';
const sectionStatus = (request,config) => getReviewEligibility(request,config);

export default function RequestWizard({ request, config, requests = [], intelligence = {}, onAnalyze, onOpenHistory, onChange, onSave, onBack, onSubmit }) {
  const [stage, setStage] = useState(0);
  const [activePlan,setActivePlan] = useState('implementation');
  const [justSaved,setJustSaved]=useState(false);
  const [validated,setValidated]=useState(false);
  const [showAllFindings,setShowAllFindings]=useState('all');
  const [inlineMessage,setInlineMessage]=useState('');
  const validation=useMemo(()=>sectionStatus(request,config),[request,config]);
  const patch=(name,value) => onChange({[name]:value});
  const setEvidence=(key,changes) => onChange({evidence:{...request.evidence,[key]:{...request.evidence[key],...changes}}});
  const onAppChange = id => {
    const app=config.applications.find(x=>x.id===id);
    const countryCodes=app?.defaultCountries || [];
    const targetServers=config.servers.filter(s=>s.applicationId===id && s.environment==='Production').map(s=>s.id);
    onChange({applicationId:id,serviceOffering:app?.serviceOffering || '',templateId:app?.template || config.policies.defaultTemplate,
      impactedCountries:countryCodes,supportingCountries:countryCodes,servers:targetServers,releaseWorkItem:'',supportingReleaseWorkItem:'',adoStories:[],plans:null});
  };
  const onReleaseChange = id => {
    const rel=config.releases.find(x=>x.id===id);
    onChange({releaseWorkItem:id,supportingReleaseWorkItem:id,adoStories:rel?.stories || []});
  };
  const handleGenerate=()=>{
    if (request.plans && !window.confirm('Regenerating will replace your edits to all four plan sections. Continue?')) return;
    const plans=generatePlans(request,config);
    if (!plans) {setInlineMessage('No deployment templates are configured. Add a template under Templates.');return;}
    patch('plans', plans); setInlineMessage('Generated 4 editable plan sections from the selected template. Review and confirm all technical instructions.');
    setActivePlan('implementation');setValidated(false);
  };
  const modifyStep=(section,index,key,value)=>{
    const next={...request.plans,[section]:request.plans[section].map((item,i)=>i===index?{...item,[key]:value}:item)};
    patch('plans',next);
  };
  const removeStep=(section,index)=>patch('plans',{...request.plans,[section]:request.plans[section].filter((_,i)=>i!==index)});
  const addStep=section=>patch('plans',{...request.plans,[section]:[...(request.plans?.[section]||[]),{id:`${section}-${Date.now()}`,title:'',description:'',owner:'',minutes:0}]});
  const save=()=>{onSave();setJustSaved(true);setTimeout(()=>setJustSaved(false),2200);};
  const next=()=>{setInlineMessage('');setStage(v=>Math.min(5,v+1));};
  const prev=()=>{setInlineMessage('');setStage(v=>Math.max(0,v-1));};
  const evidenceColour = status => status==='verified'?'success':status==='rejected'?'danger':status==='uploaded'?'info':'warning';
  const evidenceText = status => EVIDENCE_STATUSES.find(x=>x.value===status)?.label || 'Not Started';
  const filteredIssues=validation.issues.filter(x=>showAllFindings==='all'||x.severity===showAllFindings);

  return <div className="content-page">
    <div className="page-topline"><div><div className="eyebrow">CHANGE MANAGEMENT / {request.id}</div><h1>{request.shortDescription || 'New Change Request'}</h1><p className="muted">Prepare change details, generate plans and complete self-review in one place.</p></div><div className="top-actions"><span className={`status ${request.status}`}>{statusLabel(request.status)}</span><button className="btn btn-outline" onClick={onBack}><ArrowLeft size={16}/> My Requests</button><button className="btn btn-outline" onClick={save}><Save size={16}/>{justSaved?'Saved':'Save Draft'}</button></div></div>
    <div className="wizard-shell">
      <div className="stepper">{STAGES.map((s,i)=><button type="button" key={s} className={`step ${i===stage?'active':i<stage?'done':''}`} onClick={()=>{setStage(i);setInlineMessage('');}}><span className="step-num">{i<stage?<CheckCircle2 size={18}/>:i+1}</span><span>{s}</span></button>)}</div>
      <div className="wizard-body">
        {stage===0&&<>
          <div className="section-intro"><h2>Basic Information</h2><p>Enter the key details for the change request.</p></div>
          <div className="field-grid">
            <Field label="Short Description" required><TextInput value={request.shortDescription} onChange={v=>patch('shortDescription',v)} placeholder="e.g. Upgrade payment service to v2.0" maxLength={180}/></Field>
            <Field label="Change Requester" required><Select value={request.requester} onChange={v=>patch('requester',v)} options={config.users} placeholder="Select requester"/></Field>
            <Field label="Service / Application" required><Select value={request.applicationId} onChange={onAppChange} options={config.applications.map(x=>({value:x.id,label:x.name}))}/></Field>
            <Field label="Service Offering" required><TextInput value={request.serviceOffering} onChange={v=>patch('serviceOffering',v)} placeholder="Service offering"/></Field>
            <Field label="Business Justification" required className="full"><TextArea rows={4} value={request.businessJustification} onChange={v=>patch('businessJustification',v)} placeholder="Describe why this change is required and its business value."/></Field>
          </div>
          <InfoBanner>Selecting an application prefills its service offering, countries and mock production servers. All values remain editable.</InfoBanner>
        </>}
        {stage===1&&<>
          <div className="section-intro"><h2>Change Classification</h2><p>Provide risk and governance classification details.</p></div>
          <div className="field-grid">
            <Field label="Risk Level" required><Select value={request.riskLevel} onChange={v=>patch('riskLevel',v)} options={riskOptions}/></Field>
            <Field label="Nature of Change" required><Select value={request.natureOfChange} onChange={v=>patch('natureOfChange',v)} options={['Enhancement','Maintenance','Bug Fix','Security Update','Migration','New Implementation']}/></Field>
            <Field label="Change Type" required><Select value={request.changeType} onChange={v=>patch('changeType',v)} options={normOptions}/></Field>
            <Field label="Category" required><Select value={request.category} onChange={v=>patch('category',v)} options={['Application','Database','Infrastructure','Security','Network','Other']}/></Field>
            <Field label="Subcategory" required><Select value={request.subCategory} onChange={v=>patch('subCategory',v)} options={['Version Upgrade','Feature Deployment','Configuration Update','Database Patch','Security Patch','Maintenance','Other']}/></Field>
            <Field label="Backward Compatible"><Select value={request.backwardCompatible} onChange={v=>patch('backwardCompatible',v)} options={yesOptions}/></Field>
            <Field label="Automated Build"><Select value={request.automatedBuild} onChange={v=>patch('automatedBuild',v)} options={yesOptions}/></Field>
            <Field label="Additional Approvers (if any)" hint="Optional; separate names with commas"><TextInput value={request.additionalApprovers} onChange={v=>patch('additionalApprovers',v)} placeholder="e.g. DBA Lead, Security Lead"/></Field>
          </div><InfoBanner type="warning">Classification choices are mock inputs, not an automated organizational policy decision. A human owner must confirm the final risk classification.</InfoBanner>
        </>}
        {stage===2&&<>
          <div className="section-intro"><h2>Scope & Schedule</h2><p>Define impacted areas, implementation timing, releases and execution ownership.</p></div>
          <div className="field-grid">
            <Field label="Impacted Countries" required className="full"><MultiSelect values={request.impactedCountries} onChange={v=>patch('impactedCountries',v)} options={config.countries.map(x=>({value:x.code,label:x.name}))}/></Field>
            <Field label="Implementation Start Date / Time" required><TextInput type="datetime-local" value={request.implementationStart} onChange={v=>patch('implementationStart',v)}/></Field>
            <Field label="Implementation End Date / Time" required><TextInput type="datetime-local" value={request.implementationEnd} onChange={v=>patch('implementationEnd',v)}/></Field>
            <Field label="Technical Scope" required className="full"><TextArea rows={4} value={request.technicalScope} onChange={v=>patch('technicalScope',v)} placeholder="Include deployment targets, technical changes, version and operational checks."/></Field>
            <Field label="Target Server List" required className="full"><MultiSelect values={request.servers} onChange={v=>patch('servers',v)} options={config.servers.filter(s=>!request.applicationId||s.applicationId===request.applicationId).map(s=>({value:s.id,label:`${s.id} · ${s.environment}`}))}/></Field>
            <Field label="Release Work Item" required><Select value={request.releaseWorkItem} onChange={onReleaseChange} options={config.releases.filter(x=>!request.applicationId||x.applicationId===request.applicationId).map(x=>({value:x.id,label:`${x.id} — ${x.name}`}))}/></Field>
            <Field label="Deliverables" required><TextArea rows={2} value={request.deliverables} onChange={v=>patch('deliverables',v)} placeholder="List expected deliverables"/></Field>
            <Field label="Task Implementation Groups" required className="full"><MultiSelect values={request.implementationGroups} onChange={v=>patch('implementationGroups',v)} options={config.implementationGroups}/></Field>
            <Field label="Task Configuration Items" required className="full" hint="One CI per line"><ConfigurationItemsEditor items={request.configurationItems} onCommit={v=>patch('configurationItems',v)}/></Field>
            <Field label="Linked ADO Stories" className="full"><MultiSelect values={request.adoStories} onChange={v=>patch('adoStories',v)} options={config.stories.filter(x=>x.releaseId===request.releaseWorkItem).map(x=>({value:x.id,label:`${x.id} — ${x.title}`}))} emptyLabel="Select a release work item to view available stories"/></Field>
            <Field label="Prerequisite Change Requests (optional)" className="full" hint="Comma-separated CR numbers. These become explicit dependency links; confirm in the authoritative system."><TextInput value={(request.dependsOnCrIds||[]).join(', ')} onChange={v=>patch('dependsOnCrIds',v.split(',').map(x=>x.trim()).filter(Boolean))} placeholder="e.g. CHG-2026-2105, CR-2026-001"/></Field>
          </div>
          <ConflictPreview request={request} requests={requests} intelligence={intelligence} onOpenFull={onAnalyze}/>
        </>}
        {stage===3&&<>
          <div className="section-intro with-actions"><div><h2>Implementation Details</h2><p>Generate and edit standardized plans based on the selected deployment pattern.</p></div><button className="btn btn-purple" onClick={handleGenerate}><Sparkles size={16}/>{request.plans?'Regenerate Plans':'Generate Plans'}</button></div>
          <div className="field-grid compact-fields"><Field label="Deployment Pattern / Template"><Select value={request.templateId} onChange={v=>onChange({templateId:v,plans:null})} options={Object.entries(config.templates).map(([id,t])=>({value:id,label:t.label}))}/></Field><div className="muted small align-bottom">Templates are editable under the Templates page. Regeneration replaces previously edited plan sections.</div></div>
          <InfoBanner>Generated content is a draft from mock, editable templates. Verify commands, sequencing, targets, procedures, approval requirements and recovery details before production use.</InfoBanner>
          <div className="plan-tabs">{sectionKeys.map(key=><button type="button" key={key} className={activePlan===key?'current':''} onClick={()=>setActivePlan(key)}>{SECTION_LABELS[key]} <span className="tab-count">{request.plans?.[key]?.length || 0}</span></button>)}</div>
          {request.plans?<>
            <div className="plan-head"><h3>{SECTION_LABELS[activePlan]}</h3><button className="btn btn-outline btn-sm" onClick={()=>addStep(activePlan)}><Plus size={15}/> Add Step</button></div>
            <div className="plan-list">{(request.plans[activePlan]||[]).map((step,index)=><div className="plan-step" key={step.id || index}><div className="plan-step-head"><span className="step-chip">{index+1}</span><b>{step.title||'New step'}</b><button className="icon-btn danger-icon" aria-label="Remove step" onClick={()=>removeStep(activePlan,index)}><Trash2 size={16}/></button></div><div className="field-grid step-fields"><Field label="Task / Step"><TextInput value={step.title} onChange={v=>modifyStep(activePlan,index,'title',v)}/></Field><Field label="Owner"><TextInput value={step.owner} onChange={v=>modifyStep(activePlan,index,'owner',v)}/></Field><Field label="Description / Instructions" className="full"><TextArea rows={2} value={step.description} onChange={v=>modifyStep(activePlan,index,'description',v)}/></Field><Field label="Estimated Time (minutes)"><TextInput type="number" min="0" value={String(step.minutes)} onChange={v=>modifyStep(activePlan,index,'minutes',Math.max(0,Number(v)||0))}/></Field></div></div>)}</div>
            {(request.plans[activePlan]||[]).length===0&&<Empty title="No steps in this section">Add a step to complete the selected plan.</Empty>}
          </>:<Empty title="No plans generated yet">Choose a deployment template, then click Generate Plans to create four editable plan sections.</Empty>}
          <HistoricalPlanAssistant request={request} requests={requests} intelligence={intelligence} onChange={onChange}/>
        </>}
        {stage===4&&<>
          <div className="section-intro"><h2>Evidence & References</h2><p>Track supporting evidence even when UAT and Regression sign-offs are not ready.</p></div>
          <InfoBanner>You can prepare and submit a CR for lead review with pending sign-offs when the configured policy allows it. Final approval remains separate and requires the applicable verified evidence.</InfoBanner>
          <div className="evidence-grid">{Object.entries(EVIDENCE_LABELS).map(([key,label])=>{
            const e=request.evidence?.[key]||{};
            return <div className="evidence-card" key={key}><div className="evidence-title"><div className="evidence-logo"><FileCheck2 size={21}/></div><div><b>{label}</b><span className={`status mini ${evidenceColour(e.status)}`}>{evidenceText(e.status)}</span></div></div>
              <Field label="Progress"><Select value={e.status||'not_started'} onChange={v=>setEvidence(key,{status:v})} options={EVIDENCE_STATUSES}/></Field>
              <Field label="Expected Completion Date"><TextInput type="date" value={e.expectedDate} onChange={v=>setEvidence(key,{expectedDate:v})}/></Field>
              <Field label="Supporting File"><input className="file-input" type="file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.txt" onChange={event=>{const file=event.target.files?.[0];if(file)setEvidence(key,{fileName:file.name,status:'uploaded'});event.target.value='';}}/>{e.fileName&&<span className="attached-file"><FileUp size={14}/> {e.fileName} <button aria-label="Remove attachment metadata" onClick={()=>setEvidence(key,{fileName:'',status:'not_started'})}>×</button></span>}</Field>
              <Field label="Notes"><TextArea rows={2} value={e.notes||''} onChange={v=>setEvidence(key,{notes:v})} placeholder="Progress or verification notes"/></Field>
            </div>;
          })}</div>
          <div className="subsection-title"><h3>Reference Information</h3><span>7 supporting requirements, including the three document types above</span></div>
          <div className="field-grid">
            <Field label="Supporting List of Countries" hint="Use Sync to copy impacted countries; edit if the supplied evidence differs."><MultiSelect values={request.supportingCountries} onChange={v=>patch('supportingCountries',v)} options={config.countries.map(x=>({value:x.code,label:x.name}))}/><button className="link-action" onClick={()=>patch('supportingCountries',[...request.impactedCountries])}>Sync from CR</button></Field>
            <Field label="Supporting Release Work Item"><TextInput value={request.supportingReleaseWorkItem} onChange={v=>patch('supportingReleaseWorkItem',v)}/><button className="link-action" onClick={()=>patch('supportingReleaseWorkItem',request.releaseWorkItem)}>Sync from CR</button></Field>
            <div className="reference-card"><b>Server Inventory List</b><p>{request.servers.length} server(s) selected</p><div className="chip-row">{request.servers.map(s=><span className="chip static" key={s}>{s}</span>)}</div><span className="muted tiny">Manage in Scope & Schedule</span></div>
            <div className="reference-card"><b>ADO Story List</b><p>{request.adoStories.length} story/stories linked</p><div className="chip-row">{request.adoStories.map(s=><span className="chip static" key={s}>{s}</span>)}</div><span className="muted tiny">Manage in Scope & Schedule</span></div>
          </div>
          <InfoBanner type="warning">Prototype limitation: selecting a file stores its name/status only in local browser storage. File bytes are not uploaded or retained. “Verified” is a manual demo state, not a real signature verification.</InfoBanner>
        </>}
        {stage===5&&<>
          <div className="section-intro with-actions"><div><h2>Self-Review & Submission</h2><p>Validate the entire change package and review readiness before submission.</p></div><button className="btn btn-outline" onClick={()=>setValidated(true)}><RefreshCw size={16}/> Run Validation</button></div>
          <ConflictPreview request={request} requests={requests} intelligence={intelligence} onOpenFull={onAnalyze}/>
          <div className="v3-inline-history-link"><div><b>Historical CR Lessons</b><p className="muted small">Review relevant completed changes and accepted plan improvements.</p></div><button className="btn btn-outline btn-sm" onClick={onOpenHistory}>Open Historical Intelligence</button></div>
          <div className="review-cards">
            <div className="review-card"><div className="review-card-top"><span className="review-icon green"><ShieldCheck size={22}/></span><b>Plan Quality</b></div><strong>{validation.passedRules} / {validation.totalRules}</strong><span className="muted small">Configured rules passed</span><span className={`status mini ${validation.planReady?'success':'danger'}`}>{validation.planReady?'Plan Ready':'Fix Blocking Issues'}</span></div>
            <div className="review-card"><div className="review-card-top"><span className="review-icon amber"><Clock3 size={22}/></span><b>Evidence Readiness</b></div><strong>{validation.evidence.verifiedCount} / {validation.evidence.total}</strong><span className="muted small">Verified required sign-offs</span><span className={`status mini ${validation.evidence.complete?'success':'warning'}`}>{validation.evidence.complete?'Evidence Complete':'Pending Evidence'}</span></div>
            <div className="review-card"><div className="review-card-top"><span className="review-icon red"><AlertTriangle size={22}/></span><b>Findings</b></div><strong>{validation.blocking.length} <small>blocking</small></strong><span className="muted small">{validation.warnings.length} additional warning(s)</span></div>
          </div>
          <div className="review-layout"><div className="review-main">
            <div className="panel-title"><h3>Validation Results</h3><div className="pill-tabs">{[['all','All'],['blocking','Blocking'],['warning','Warnings']].map(([k,t])=><button key={k} className={showAllFindings===k?'active':''} onClick={()=>setShowAllFindings(k)}>{t}</button>)}</div></div>
            {filteredIssues.length?<div className="findings">{filteredIssues.map((f,i)=><div className="finding" key={`${f.id}-${i}`}><span className={`finding-icon ${f.severity}`}>{f.severity==='blocking'?<AlertTriangle size={18}/>:<CircleHelp size={18}/>}</span><div><div className="finding-heading"><b>{f.id} — {f.location}</b><span className={`status mini ${f.severity==='blocking'?'danger':'warning'}`}>{f.severity}</span></div><p>{f.message}</p><div className="suggestion"><b>Suggested action:</b> {f.suggestion}</div></div></div>)}</div>:<div className="success-empty"><CheckCircle2 size={26}/><b>No issues in this view</b><p>The selected validation checks have no findings.</p></div>}
            <InfoBanner type="info">“Smart review” uses transparent local rules and text heuristics in this offline prototype; no real LLM or backend is connected.</InfoBanner>
          </div><aside className="review-side"><div className="panel-title"><h3>Change Request Summary</h3></div><dl className="summary-dl">{[['CR ID',request.id],['Application',nameForApp(config,request.applicationId)],['Risk',request.riskLevel],['Requester',request.requester || '—'],['Change window',`${dateFmt(request.implementationStart)} → ${dateFmt(request.implementationEnd)}`],['Countries',request.impactedCountries.join(', ') || '—'],['Servers',request.servers.join(', ') || '—'],['Release',request.releaseWorkItem || '—']].map(([k,v])=><React.Fragment key={k}><dt>{k}</dt><dd>{v}</dd></React.Fragment>)}</dl><hr/><h4>Generated Documents</h4>{sectionKeys.map(k=><div className="small-row" key={k}><span>{SECTION_LABELS[k]}</span><span className={`status mini ${request.plans?.[k]?.length?'success':'warning'}`}>{request.plans?.[k]?.length?'Generated':'Missing'}</span></div>)}<hr/><h4>Supporting Sign-offs</h4>{validation.evidence.signoffs.map(e=><div className="small-row" key={e.key}><span>{e.label}</span><span className={`status mini ${evidenceColour(e.status)}`}>{evidenceText(e.status)}</span></div>)}<hr/><div className="small-row"><b>Lead review</b><span className={`status mini ${validation.canSubmitForReview?'success':'danger'}`}>{validation.canSubmitForReview?'Allowed':'Blocked'}</span></div><div className="small-row"><b>Final evidence gate</b><span className={`status mini ${validation.canFinalApprove?'success':'warning'}`}>{validation.canFinalApprove?'Checks Passed':'Not Ready'}</span></div></aside></div>
          {request.reviewSubmitted&&<InfoBanner type="success"><CheckCircle2 size={17}/> This request was marked submitted for lead review. Current status: {statusLabel(request.status)}. This is a local prototype state, not a real change-management-system submission.</InfoBanner>}
          <div className="submit-actions"><button className="btn btn-outline" onClick={()=>exportJson(request)}><Download size={16}/> Export JSON</button><button className="btn btn-outline" onClick={()=>exportHtml(request,config)}><Download size={16}/> Export Review Package</button><button className="btn btn-primary" disabled={!validation.canSubmitForReview} onClick={()=>{onSubmit();setValidated(true);}}><ClipboardCheck size={17}/> {request.reviewSubmitted?'Resubmit for Lead Review':'Submit for Lead Review'}</button></div>
          {!validation.canSubmitForReview&&<p className="danger-text small">Resolve blocking validation findings before submitting for lead review. Missing sign-offs alone are allowed when the configured policy permits.</p>}
        </>}
        {inlineMessage&&<InfoBanner>{inlineMessage}</InfoBanner>}
        <div className="wizard-footer"><button className="btn btn-outline" onClick={stage===0?onBack:prev}><ArrowLeft size={16}/>{stage===0?'My Requests':'Previous'}</button><div className="footer-right"><button className="btn btn-outline" onClick={save}><Save size={16}/> Save Draft</button>{stage<5&&<button className="btn btn-primary" onClick={next}>Next <ArrowRight size={16}/></button>}</div></div>
      </div>
    </div>
  </div>;
}
