import React from 'react';

export function Field({ label, required, hint, children, className = '' }) {
  return <label className={`field ${className}`}><span className="field-label">{label}{required && <em> *</em>}</span>{children}{hint && <span className="field-hint">{hint}</span>}</label>;
}
export function TextInput({ value, onChange, placeholder='', type='text', ...props }) {
  return <input className="input" value={value ?? ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} type={type} {...props}/>;
}
export function TextArea({ value, onChange, rows=3, placeholder='', ...props }) {
  return <textarea className="input textarea" rows={rows} value={value ?? ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} {...props}/>;
}
export function Select({ value, onChange, options, placeholder='Select an option', ...props }) {
  return <select className="input" value={value ?? ''} onChange={e => onChange(e.target.value)} {...props}><option value="">{placeholder}</option>{options.map(o => { const x=typeof o==='string' ? {value:o,label:o} : o; return <option key={x.value} value={x.value}>{x.label}</option>; })}</select>;
}
export function MultiSelect({ values=[], onChange, options, emptyLabel='Nothing selected', disabled=false }) {
  return <div className="multiselect">{values.length ? <div className="chip-row">{values.map(value => <button type="button" className="chip" key={value} onClick={() => !disabled && onChange(values.filter(v => v !== value))}>{options.find(x => (typeof x === 'string' ? x : x.value) === value)?.label || value} <span aria-hidden>×</span></button>)}</div> : <span className="muted small">{emptyLabel}</span>}<div className="option-row">{options.filter(o => !values.includes(typeof o==='string'?o:o.value)).map(option => {const x=typeof option==='string'?{value:option,label:option}:option;return <button type="button" className="small-add" key={x.value} disabled={disabled} onClick={() => onChange([...values,x.value])}>+ {x.label}</button>;})}</div></div>;
}
export function InfoBanner({ children, type='info' }) { return <div className={`info-banner ${type}`}>{children}</div>; }
export function Empty({ title, children }) { return <div className="empty"><div className="empty-icon">◇</div><b>{title}</b><p>{children}</p></div>; }
