import React,{useEffect,useMemo,useState} from 'react';
import {History,BookOpen,Search,ShieldCheck,AlertTriangle,CheckCircle2,RefreshCw,Sparkles,Plus,Save,Eye,GitCompareArrows,Info,BrainCircuit,FileCheck2} from 'lucide-react';
import {compareHistoricalCRs,completedChanges,outcomeState,outcomeLabels,proposePlanLessons,applyPlanSuggestion} from '../lib/historical.js';
import {Field,TextInput,TextArea,Select,InfoBanner,Empty} from './Fields.jsx';

const labels={implementation:'Implementation Plan',pit:'PIT Plan',backout:'Backout Plan',risk:'Risk & Impact Analysis'};
const fmt=timestamp=>timestamp?new Date(timestamp).toLocaleDateString('en-MY',{day:'numeric',month:'short',year:'numeric'}):'—';
const badgeColor=x=>x==='successful'?'success':x==='unknown'?'warning':'danger';
const outcomeOptions=[{value:'unknown',label:'Unknown / not verified'},{value:'successful',label:'Successful'},{value:'unsuccessful',label:'Unsuccessful'},{value:'rolled_back',label:'Rolled back'}];

function LessonCard({item,request,onChange}){
 const [editing,setEditing]=useState(false);
 const [title,setTitle]=useState(item.title);
 const [description,setDescription]=useState(item.description);
 const [owner,setOwner]=useState(item.owner);
 const exists=!!(request.plans?.[item.section]||[]).find(x=>x.sourceSuggestionId===item.id||String(x.title||'').trim().toLowerCase()===item.title.toLowerCase());
 const decision=request.historyReview?.[item.id]?.status||null;
 const updateDecision=status=>({...request.historyReview,[item.id]:{status,sourceCrId:item.sourceCrId,section:item.section,updatedAt:new Date().toISOString()}});
 const accept=()=>{
  const plans=applyPlanSuggestion(request,item,{title,description,owner});
  if(!plans)return;
  onChange({plans,historyReview:updateDecision('accepted')});setEditing(false);
 };
 const dismiss=()=>onChange({historyReview:updateDecision('dismissed')});
 const reset=()=>onChange({historyReview:updateDecision('pending')});
 return <div className={`v3-lesson ${exists?'v3-added':decision==='dismissed'?'v3-dismissed':''}`}>
  <div className="v3-lesson-top"><div><span className="v3-mini-label">{labels[item.section]}</span><h4>{item.title}</h4><p className="muted small">Source {item.sourceCrId} · Match {item.similarityScore}/100 · {outcomeLabels[item.observedOutcome]}</p></div>
   {exists?<span className="v3-tag success">Added to plan</span>:decision==='dismissed'?<span className="v3-tag neutral">Dismissed</span>:<span className="v3-tag info">Review suggested step</span>}</div>
  <p>{item.rationale}</p><div className="v3-suggested-step"><b>Suggested content:</b> {item.description}</div>
  {!exists&&decision!=='dismissed'&&editing&&<div className="v3-inline-edit"><Field label="Step title"><TextInput value={title} onChange={setTitle}/></Field><Field label="Instructions"><TextArea value={description} onChange={setDescription} rows={3}/></Field><Field label="Owner"><TextInput value={owner} onChange={setOwner}/></Field></div>}
  <div className="v3-lesson-actions">
   {exists?<span className="positive-text small"><CheckCircle2 size={14}/> Present in editable plan</span>:decision==='dismissed'?<button className="btn btn-outline btn-sm" onClick={reset}><RefreshCw size={14}/> Reconsider</button>:<><button className="btn btn-outline btn-sm" onClick={()=>setEditing(x=>!x)}>{editing?'Cancel Edit':'Edit Proposal'}</button><button className="btn btn-outline btn-sm" onClick={dismiss}>Dismiss</button><button className="btn btn-primary btn-sm" disabled={!request.plans||!title.trim()||!description.trim()} onClick={accept}><Plus size={14}/> Accept into Plan</button></>}
  </div>
  {!request.plans&&!exists&&decision!=='dismissed'&&<p className="muted tiny">Generate the plan first to enable acceptance.</p>}
 </div>;
}
export function HistoricalPlanAssistant({request,requests,intelligence,onChange}){
 const suggestions=useMemo(()=>proposePlanLessons(request,requests,intelligence),[request,requests,intelligence]);
 const matched=useMemo(()=>compareHistoricalCRs(request,requests,intelligence),[request,requests,intelligence]);
 const [expanded,setExpanded]=useState(true);
 return <div className="v3-assistant"><div className="v3-assistant-head"><div className="v3-assistant-icon"><BrainCircuit size={23}/></div><div><h3>Historical Plan Improvement</h3><p>Review traceable lessons from completed CRs before adding them to this plan.</p></div><button className="btn btn-outline btn-sm" onClick={()=>setExpanded(x=>!x)}>{expanded?'Collapse':'Expand'}</button></div>
  <div className="v3-info-strip"><span><b>{matched.length}</b> completed CR matches</span><span><b>{suggestions.length}</b> proposed checks</span><span><b>{suggestions.filter(s=>(request.plans?.[s.section]||[]).some(x=>x.sourceSuggestionId===s.id)).length}</b> accepted steps present</span></div>
  {expanded&&<><InfoBanner type="info">Suggestions are generated from curated synthetic historical lessons using deterministic matching—not a connected LLM. They are never inserted automatically and require developer confirmation. Historical similarity is not failure likelihood.</InfoBanner>
   {suggestions.length?suggestions.map(s=><LessonCard key={s.id} item={s} request={request} onChange={onChange}/>):<Empty title="No relevant historical lessons">Complete the application and technical scope, or add comparable historical CRs in the mock data.</Empty>}
  </>}
 </div>;
}
export function HistoricalIntelligencePage({requests,intelligence,config,onOpen,onIntelligenceChange}){
 const [selectedId,setSelectedId]=useState(requests[0]?.id||'');
 const [search,setSearch]=useState('');const [app,setApp]=useState('ALL');const [outcomeFilter,setOutcomeFilter]=useState('ALL');
 const [selectedHistory,setSelectedHistory]=useState('');const [editOutcome,setEditOutcome]=useState('unknown');const [editNote,setEditNote]=useState('');const [editVerified,setEditVerified]=useState(false);
 const choices=useMemo(()=>[...requests.filter(x=>x.applicationId||x.shortDescription),...(intelligence.bankChanges||[]).filter(x=>String(x.snowState).toLowerCase()!=='closed')],[requests,intelligence.bankChanges]);
 const target=choices.find(x=>x.id===selectedId)||choices[0];
 const matches=useMemo(()=>target?compareHistoricalCRs(target,requests,intelligence):[],[target,requests,intelligence]);
 const library=useMemo(()=>completedChanges(requests,intelligence).filter(x=>(app==='ALL'||x.applicationId===app)&&(outcomeFilter==='ALL'||outcomeState(x)===outcomeFilter)&&`${x.id} ${x.shortDescription||''} ${x.outcomeNotes||''}`.toLowerCase().includes(search.toLowerCase())),[requests,intelligence,app,outcomeFilter,search]);
 const record=completedChanges(requests,intelligence).find(x=>x.id===selectedHistory)||library[0];
 useEffect(()=>{if(!record)return;setEditOutcome(record.outcome||'unknown');setEditNote(record.outcomeNotes||'');setEditVerified(!!record.outcomeVerified);},[record?.id,record?.outcome,record?.outcomeNotes,record?.outcomeVerified]);
 const saveOutcome=()=>{if(!record||!(intelligence.bankChanges||[]).some(r=>r.id===record.id))return;
  onIntelligenceChange({...intelligence,bankChanges:intelligence.bankChanges.map(r=>r.id===record.id?{...r,outcome:editOutcome,outcomeNotes:editNote,outcomeVerified:editVerified}:r)});
 };
 return <div className="content-page"><div className="page-topline"><div><div className="eyebrow">HISTORICAL INTELLIGENCE · DEMO RECORDS</div><h1>Completed CR Intelligence</h1><p className="muted">Search completed changes, inspect verified outcomes and identify reviewable lessons for new plans.</p></div><span className="cg-demo-tag">SYNTHETIC HISTORY</span></div>
 <div className="surface-panel"><div className="panel-title"><div><h2>Compare a new or upcoming CR</h2><p>Use scope, CIs and text similarity to retrieve completed-change precedents.</p></div></div><div className="v3-select-line"><Field label="Change to compare"><select className="input" value={target?.id||''} onChange={e=>setSelectedId(e.target.value)}>{choices.map(x=><option key={x.id} value={x.id}>{x.id} — {x.shortDescription}</option>)}</select></Field>{target&&requests.some(x=>x.id===target.id)&&<button className="btn btn-outline" onClick={()=>onOpen(target.id)}><Eye size={15}/> Open local CR</button>}</div>
 <div className="v3-match-list">{matches.length?matches.slice(0,4).map(x=><div key={x.id} className="v3-match-card"><div className="v3-match-head"><div><b>{x.id}</b> · {x.shortDescription}<p className="muted small">{x.matchingReasons.join(' · ')}</p></div><span className="v3-score">Match {x.similarityScore}/100</span></div><div className="v3-match-foot"><span className={`v3-tag ${badgeColor(x.observedOutcome)}`}>{outcomeLabels[x.observedOutcome]}</span><span className="muted small">{x.outcomeNotes||'No historical note provided.'}</span></div></div>):<Empty title="No completed CR matches">Try a different upcoming change or adjust the editable similarity threshold.</Empty>}</div></div>
 <div className="v3-columns"><div className="surface-panel"><div className="panel-title"><div><h2>Completed Change Library</h2><p>View outcomes without assuming closed means successful.</p></div><span className="muted small">{library.length} records</span></div><div className="v3-filterrow"><div className="cg-search"><Search size={16}/><input aria-label="Search completed changes" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search history"/></div><select className="input" value={app} onChange={e=>setApp(e.target.value)}><option value="ALL">All services</option>{config.applications.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select><select className="input" value={outcomeFilter} onChange={e=>setOutcomeFilter(e.target.value)}><option value="ALL">All outcomes</option>{outcomeOptions.map(x=><option key={x.value} value={x.value}>{x.label}</option>)}</select></div><div className="v3-library">{library.map(r=><button key={r.id} className={`v3-library-item ${record?.id===r.id?'chosen':''}`} onClick={()=>setSelectedHistory(r.id)}><div><b>{r.id}</b><span>{r.shortDescription}</span><small className="muted">{fmt(r.implementationEnd)} · {r.applicationId}</small></div><span className={`v3-tag ${badgeColor(outcomeState(r))}`}>{outcomeLabels[outcomeState(r)]}</span></button>)}{!library.length&&<Empty title="No results">Adjust the library filters.</Empty>}</div></div>
 <div className="surface-panel"><div className="panel-title"><div><h2>Outcome & Learning Record</h2><p>Inspectable history with source reference and mock verification state.</p></div></div>{record?<><div className="v3-outcome-summary"><b>{record.id}</b><h3>{record.shortDescription}</h3><span className={`v3-tag ${badgeColor(outcomeState(record))}`}>{outcomeLabels[outcomeState(record)]} {record.outcomeVerified?'· Verified mock fixture':'· Not verified'}</span><p className="muted small">Recorded incidents: {(record.linkedIncidents||[]).join(', ')||'None linked'} · Rollback: {record.rollbackExecuted===true?'Yes':record.rollbackExecuted===false?'No':'Unknown'}</p></div><div className="v3-history-lessons"><h3>Recorded Lessons</h3>{(record.lessonsLearned||[]).map(l=><div key={l.id} className="v3-lesson-short"><b>{labels[l.section]} · {l.title}</b><p>{l.context}</p><small>{l.description}</small></div>)}{!(record.lessonsLearned||[]).length&&<p className="muted">No curated lessons attached.</p>}</div><div className="v3-outcome-edit"><h3>Update synthetic outcome</h3><p className="muted small">This only edits browser mock data and is not a SNOW verification or closure action.</p><Field label="Outcome"><Select value={editOutcome} onChange={setEditOutcome} options={outcomeOptions}/></Field><Field label="Closure / lesson summary"><TextArea rows={3} value={editNote} onChange={setEditNote}/></Field><label className="v3-check"><input type="checkbox" checked={editVerified} onChange={e=>setEditVerified(e.target.checked)}/> Mark as verified in demo data (manual simulation)</label><button className="btn btn-primary" onClick={saveOutcome}><Save size={15}/> Save Local Outcome</button></div></>:<Empty title="Select a completed change">No record is selected.</Empty>}</div></div>
 <InfoBanner type="warning">Completed-change outcomes, incidents and verification are entirely fictional demonstration fixtures. No live SNOW, ADO, CMDB, LLM, or bank-wide data access is used.</InfoBanner>
 </div>;
}
